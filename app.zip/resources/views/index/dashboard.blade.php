@extends('layouts.app')

@extends('layouts.structure')

@section('section')

<h1>bienvenido</h1>

@endsection