@extends('layouts.app')

@extends('layouts.structure')

@section('section')

<h1>bienvenido a la seccion de Administracion</h1>

@endsection