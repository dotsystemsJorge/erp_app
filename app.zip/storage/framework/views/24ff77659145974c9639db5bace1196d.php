



<?php $__env->startSection('section'); ?>

<section id="Store">

    <div class="container">
        <div>
            <?php echo $__env->make('layouts.navigation_panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="">
            <h2 class="text-light">Sucursal <span class="text-arg">xxx</span></h2>
        </div>
        <div class="">
            <h4 class="text-light">Almacenes disponibles</h4>
            <table class="table table-hover table-dark">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Detalle</th>
                    <th scope="col">Acción</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>1001</th>
                    <td>Disponibles</td>
                    <td>
                        <a href="<?php echo e(route('warehouse')); ?>"><i class="bi bi-eye text-info"></i></a>
                    </td>
                  </tr>
                  <tr>
                    <th>1002</th>
                    <td>Servicio Técnico</td>
                    <td>
                        <a href="<?php echo e(route('warehouse')); ?>"><i class="bi bi-eye text-info"></i></a>
                    </td>
                  </tr>
                  <tr>
                    <th>1003</th>
                    <td>Inoperativos</td>
                    <td>
                        <a href="<?php echo e(route('warehouse')); ?>"><i class="bi bi-eye text-info"></i></a>
                    </td>
                  </tr>
                  <tr>
                    <th>1004</th>
                    <td>Reservados</td>
                    <td>
                        <a href="<?php echo e(route('warehouse')); ?>"><i class="bi bi-eye text-info"></i></a>
                    </td>
                  </tr>
                  <tr>
                    <th>1005</th>
                    <td>Scrap</td>
                    <td>
                        <a href="<?php echo e(route('warehouse')); ?>"><i class="bi bi-eye text-info"></i></a>
                    </td>
                  </tr>
                </tbody>
            </table>
        </div>
        
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp_app\resources\views/stock/branches/branch.blade.php ENDPATH**/ ?>