



<?php $__env->startSection('section'); ?>

<section id="Store">

    <div class="container">
        <div class="col-12">
            <nav aria-label="breadcrumb" style="--bs-breadcrumb-divider: '';">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home ></a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Sucursales ></a>
                    </li>
                    <li class="breadcrumb-item mx-0 px-0">
                        <a href="#">Almacenes ></a>
                    </li>
                    <li class="breadcrumb-item mx-0 px-0 active" aria-current="page">Sección</li>
                </ol>
            </nav>
        </div>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp_app\resources\views/stock/stores/store.blade.php ENDPATH**/ ?>