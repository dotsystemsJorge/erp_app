



<?php $__env->startSection('section'); ?>

<h1>bienvenido a la seccion de CRM</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp_app\resources\views/CRM/index.blade.php ENDPATH**/ ?>