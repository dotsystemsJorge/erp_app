<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    </head>
    <body class="bg-light">
        <?php if(auth()->guard()->check()): ?>
        <nav class="flex gap-2 items-center">
            <a href="" class="">
                Crear post
            </a>
            <a class="font-bold text-gray-600" href="">Hola <span class="font-normal"> </span></a>
            <form method="POST" action="">
                <?php echo csrf_field(); ?>
                <button type="submit" class="font-bold uppercase text-gray-600">Logoff</button>
            </form>
        </nav>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
        <nav class="flex gap-2 items-center">
            <a class="font-bold uppercase text-gray-600" href="">Login</a>
            <a class="font-bold uppercase text-gray-600" href="">Crear Cuenta</a>
        </nav>
        <?php endif; ?>


        <main>

        </main>

        <footer class="text-center mt-10 p-5 text-gray-500 font-bold uppercase">
        DevStagram - All rights reserved <?php echo e(now()->year); ?> 
        </footer>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\erp_app\resources\views/welcome.blade.php ENDPATH**/ ?>